create database yum

create table tblClient
(
	ClientID varchar(20) not null primary key,
	ClientName varchar(30),
	ClientAddress varchar(30),
	ClientPhone varchar(20),
	ClientEmail varchar(20)
)

create table tblType
(
	TypeID varchar(20) not null primary key,
	TypeName varchar(30)

)


create table tblEquipment
(
	EquipmentID varchar(20) not null primary key,
	TypeID varchar(20),
	EquipmentName varchar(30),
	Price varchar(20),
	Foreign key(TypeID) References tblType(TypeID)
)

create table tblWaterType
(
	WaterTypeID varchar(20) not null primary key,
	WaterTypeName varchar(30)
)

create table tblFish
(
	FishCode varchar(20) not null primary key,
	FishType varchar(30),
	WaterTypeID varchar(20),
	foreign key(WaterTypeID)references tblWaterType(WaterTypeID)
)

create table tblStaff
(
	StaffID varchar(20)not null primary key,
	StafffName varchar(30),
	StaffPosition varchar(30),
	StaffAddress varchar(30),
	StaffPhone varchar(20),
	StafffEmail varchar(20)
)


create table tblProject
(
	ProjectID varchar(20) not null primary key,
	ClientID varchar(20),
	ProjectDate datetime,
	ProjectDuration varchar(20)
)

create Table tblProjectFish
(
	ProjectID varchar(20),
	FishCode varchar(20),
	Foreign key(ProjectID) References tblProject,
	Foreign key(FishCode) References tblFish

)


create TAble tblProjectEquipment
(
	ProjectID varchar(20),
	EquipmentID varchar(20),
	Foreign key(ProjectID) References tblProject,
	Foreign key(EquipmentID) References tblEquipment

)


create table tblProjectStaff
(
	ProjectID varchar(20),
	StaffID varchar(20),
	Foreign key(ProjectID) References tblProject,
	Foreign key(StaffID) References tblStaff

)


insert into tblClient values('C-001','Janus Enterprises','Yangon','22222','aa@gmail.com')
insert into tblClient values('C-002','Hackney Library Service','Mandalay','33333','ss@gmail.com')
insert into tblClient values('C-003','Aye Soe','MyitgyiNar','11111','as@gmail.com')
insert into tblClient values('C-004','Kay Kay','Yangon','27777','kk@gmail.com')
insert into tblClient values('C-005','Ju Ju','Yangon','22888','jj@gmail.com')
insert into tblClient values('C-006','Lain Lain','Mawlamyine','29999','ll@gmail.com')
insert into tblClient values('C-007','Shwe Mya War','MuDone','82222','shwe@gmail.com')
insert into tblClient values('C-008','Saw Saw','Yangon','55555','saw@gmail.com')
insert into tblClient values('C-009','Chai Chai','Yangon','29999','cc@gmail.com')
insert into tblClient values('C-010','Ei Ei','Yangon','29922','ee@gmail.com')


Select * from tblClient



insert into tblStaff values('S-001','Dave Smith','Installer','Yangon','11122','mi@gmail.com','100')
insert into tblStaff values('S-002','Julian Kelly','Labourer','Yangon','55522','m@gmail.com','150')
insert into tblStaff values('S-003','Jason Mason','Fish Expert','Yangon','8822','mm@gmail.com','200')
insert into tblStaff values('S-004','Annie HAll','Fish Expert','Yangon','11122','sm@gmail.com','200')
insert into tblStaff values('S-005','Winston Sunday','Labourer','Yangon','11122','tt@gmail.com','150')
insert into tblStaff values('S-006','Nan Nan','Receptionist','Yangon','11122','nn@gmail.com','100')

Select * from tblStaff


insert into tblProject values('45435','C-001','01-01-2013','3 months')
insert into tblProject values('67867','C-001','04-01-2013','1 month')
insert into tblProject values('34300','C-002','02-11-2012','2 months')
insert into tblProject values('13562','C-003','01-01-2013','1 months')
insert into tblProject values('24557','C-004','04-01-2013','2 month')
insert into tblProject values('35777','C-005','03-11-2012','2 months')


Select * from tblProject


insert into tblType values('T-001','Aeration and Filtration Unit')
insert into tblType values('T-002','Fittings')
insert into tblType values('T-003','Tank')
insert into tblType values('T-004','Service Unit')
insert into tblType values('T-005','Fittnesss Unit')
insert into tblType values('T-006','Aeration  Unit')


Select * from tblType

insert into tblEquipment values('E-001','T-001','KingFilteration Unit','100.00','100')
insert into tblEquipment values('E-002','T-002','Standard Fravel','25.00','25')
insert into tblEquipment values('E-003','T-002','Standard Plants','10.00','10')
insert into tblEquipment values('E-004','T-003','Volvan Unit','100.00','100')
insert into tblEquipment values('E-005','T-001','Large Marine Tank','550.00','550')
insert into tblEquipment values('E-006','T-004','Queen Unit','100.00','400')
insert into tblEquipment values('E-007','T-005','Alteration Service Unit','200.00','450')
insert into tblEquipment values('E-009','T-006','Plants','200.00','200')
insert into tblEquipment values('E-010','T-006','Small Tank','100.00','300')

Select * from tblEquipment


insert into tblWaterType values('W-001','Marine')
insert into tblWaterType values('W-002','Fresh Water Cold')
insert into tblWaterType values('W-003','Fresh Water Tropical')
insert into tblWaterType values('W-004','Freeze Water')
insert into tblWaterType values('W-005','Warm Water')


Select * from tblWaterType

insert into tblFish values('F-001','Clown Fish,Miniature Sharks','W-001','10')
insert into tblFish values('F-002','Miniature Sharks','W-001','20')
insert into tblFish values('F-003','Gold Fish','W-002','15')
insert into tblFish values('F-004','Crap','W-002','10')
insert into tblFish values('F-005','Guppies','W-003','22')
insert into tblFish values('F-006','Neon Tetras','W-003','40')
insert into tblFish values('F-007','Reef fish','W-004','20')
insert into tblFish values('F-008','Bebe Squid','W-004','30')
insert into tblFish values('F-009','Guppies','W-005','33')


Select * from tblFish


insert into tblProjectEquipment values('35777','E-001','30')
insert into tblProjectEquipment values('45435','E-002','90')
insert into tblProjectEquipment values('67867','E-003','30')
insert into tblProjectEquipment values('34300','E-004','60')
insert into tblProjectEquipment values('13562','E-005','60')
insert into tblProjectEquipment values('24557','E-006','30')



Select * from tblProjectEquipment



insert into tblProjectFish values('35777','F-001','10')
insert into tblProjectFish values('45435','F-002','20')
insert into tblProjectFish values('67867','F-003','20')
insert into tblProjectFish values('34300','F-004','20')
insert into tblProjectFish values('13562','F-005','30')
insert into tblProjectFish values('24557','F-006','30')




Select * from tblProjectFish


insert into tblProjectStaff values('35777','S-001')
insert into tblProjectStaff values('45435','S-002')
insert into tblProjectStaff values('67867','S-003')
insert into tblProjectStaff values('13562','S-004')
insert into tblProjectStaff values('34300','S-005')


Select * from tblProjectStaff


Select P.*,PS.*
From tblProject P,tblProjectStaff PS
Where P.ProjectID=PS.ProjectID

Select S.*,PS.*
From tblStaff S,tblProjectStaff PS
Where PS.StaffID=S.StaffID

Select P.*,PE.*
From tblProject P,tblProjectEquipment PE
Where P.ProjectID=PE.ProjectID

Select PE.*,E.*
From tblProjectEquipment PE,tblEquipment E
Where PE.EquipmentID=E.EquipmentID


Select E.*,T.*
From tblEquipment E,tblType T
Where E.TypeID=T.TypeID

Select P.*,PF.*
From tblProject P,tblProjectFish PF
Where P.ProjectID=PF.ProjectID

Select F.*,PF.*
From tblFish F,tblProjectFish PF
Where F.FishCode=PF.FishCode

Select F.*,WT.*
From tblFish F,tblWaterType WT
Where F.WaterTypeID=WT.WaterTypeID


Select S.*,PS.*,P.*

Select PS.*,s.StafffName
From tblStaff S,tblProjectStaff PS,tblProject P
Where S.StaffID=PS.StaffID and PS.ProjectID=P.ProjectID

Select PE.*,E.EquipmentName
From tblEquipment E,tblProjectEquipment PE,tblProject P
Where E.EquipmentID=PE.EquipmentID and PE.ProjectID=P.ProjectID

Select PF.*,F.FishType
From tblFish F,tblProjectFish PF,tblProject P
Where F.FishCode=PF.FishCode and PF.ProjectID=P.ProjectID

Select PF.*,F.FishType,WT.WaterTypeName
From tblFish F,tblProjectFish PF,tblWaterType WT
Where F.FishCode=PF.FishCode and F.WaterTypeID=WT.WaterTypeID


Alter Table tblProjectStaff
ADD StaffAmount Float

Select * from tblProjectStaff

Alter Table tblProjectEquipment
ADD EquipmentAmount Float

Select * from tblProjectEquipment

Alter Table tblProjectFish
ADD FishAmount Float

Select * from tblProjectEquipment

Alter Table tblProject
Add StaffTotalAmount Float

Alter Table tblProject
Add EquipmentTotalAmount Float

Alter Table tblProject
Add FishTotalAmount Float

Alter Table tblProject
Add ProjectTotalCost Float

Select * from tblProject


Update tblProjectStaff
Set StaffAmount=TotalDays*StaffFees
From tblProjectStaff PS,tblStaff S
Where S.StaffID=PS.StaffID

Select * from tblProjectStaff

Update tblProjectEquipment
Set EquipmentAmount=Duration*Price
From tblProjectEquipment PE,tblEquipment E
Where E.EquipmentID=PE.EquipmentID

Select * from tblProjectEquipment

Update tblProjectFish
Set FishAmount=FishCost*Quantity
From tblProjectFish PF,tblFish F
Where F.FishCode=PF.FishCode


Select * from tblProjectFish


Update tblProject
Set StaffTotalAmount=(Select Sum(StaffAmount)From tblProjectStaff where ProjectID=35777)
Where ProjectID=35777

Update tblProject
Set StaffTotalAmount=(Select Sum(StaffAmount)From tblProjectStaff where ProjectID=45435)
Where ProjectID=45435

Update tblProject
Set StaffTotalAmount=(Select Sum(StaffAmount)From tblProjectStaff where ProjectID=67867)
Where ProjectID=67867


Update tblProject
Set StaffTotalAmount=(Select Sum(StaffAmount)From tblProjectStaff where ProjectID=34300)
Where ProjectID=34300

Update tblProject
Set StaffTotalAmount=(Select Sum(StaffAmount)From tblProjectStaff where ProjectID=13562)
Where ProjectID=13562


Update tblProject
Set StaffTotalAmount=(Select Sum(StaffAmount)From tblProjectStaff where ProjectID=24557)
Where ProjectID=24557

Select * from tblProject

Update tblProject
Set EquipmentTotalAmount=(Select Sum(EquipmentAmount)From tblProjectEquipment where ProjectID=13562)
Where ProjectID=13562

Update tblProject
Set EquipmentTotalAmount=(Select Sum(EquipmentAmount)From tblProjectEquipment where ProjectID=35777)
Where ProjectID=35777

Update tblProject
Set EquipmentTotalAmount=(Select Sum(EquipmentAmount)From tblProjectEquipment where ProjectID=45435)
Where ProjectID=45435

Update tblProject
Set EquipmentTotalAmount=(Select Sum(EquipmentAmount)From tblProjectEquipment where ProjectID=67867)
Where ProjectID=67867


Update tblProject
Set EquipmentTotalAmount=(Select Sum(EquipmentAmount)From tblProjectEquipment where ProjectID=34300)
Where ProjectID=34300




Update tblProject
Set EquipmentTotalAmount=(Select Sum(EquipmentAmount)From tblProjectEquipment where ProjectID=24557)
Where ProjectID=24557

Select * from tblProject


Update tblProject
Set FishTotalAmount=(Select Sum(FishAmount)From tblProjectFish where ProjectID=13562)
Where ProjectID=13562

Update tblProject
Set FishTotalAmount=(Select Sum(FishAmount)From tblProjectFish where ProjectID=35777)
Where ProjectID=35777

Update tblProject
Set FishTotalAmount=(Select Sum(FishAmount)From tblProjectFish where ProjectID=45435)
Where ProjectID=45435

Update tblProject
Set FishTotalAmount=(Select Sum(FishAmount)From tblProjectFish where ProjectID=67867)
Where ProjectID=67867


Update tblProject
Set FishTotalAmount=(Select Sum(FishAmount)From tblProjectFish where ProjectID=34300)
Where ProjectID=34300




Update tblProject
Set FishTotalAmount=(Select Sum(FishAmount)From tblProjectFish where ProjectID=24557)
Where ProjectID=24557

Select * from tblProject

Update tblProject
Set ProjectTotalCost=(Select Sum(StaffTotalAmount+EquipmentTotalAmount+FishTotalAmount)From tblProject where ProjectID=13562)
Where ProjectID=13562

Update tblProject
Set ProjectTotalCost=(Select Sum(StaffTotalAmount+EquipmentTotalAmount+FishTotalAmount)From tblProject where ProjectID=35777)
Where ProjectID=35777

Update tblProject
Set ProjectTotalCost=(Select Sum(StaffTotalAmount+EquipmentTotalAmount+FishTotalAmount)From tblProject where ProjectID=45435)
Where ProjectID=45435

Update tblProject
Set ProjectTotalCost=(Select Sum(StaffTotalAmount+EquipmentTotalAmount+FishTotalAmount)From tblProject where ProjectID=67867)
Where ProjectID=67867


Update tblProject
Set ProjectTotalCost=(Select Sum(StaffTotalAmount+EquipmentTotalAmount+FishTotalAmount)From tblProject where ProjectID=34300)
Where ProjectID=34300




Update tblProject
Set ProjectTotalCost=(Select Sum(StaffTotalAmount+EquipmentTotalAmount+FishTotalAmount)From tblProject where ProjectID=24557)
Where ProjectID=24557

Select * from tblProject
